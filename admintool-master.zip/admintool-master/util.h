#ifndef UTIL_H
#define UTIL_H

#include <QString>

QString BuildPath(const char *file);

#endif // UTIL_H
